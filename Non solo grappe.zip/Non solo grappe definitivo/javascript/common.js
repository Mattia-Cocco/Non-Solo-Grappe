window.onload = function () {
    common();
};